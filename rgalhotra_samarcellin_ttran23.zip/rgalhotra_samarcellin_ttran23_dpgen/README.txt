# Author: Rohin Galhotra (574a), Stephanie Marcellin (574a), Tam Tran (474a)
# NetID: rgalhotra, samarcellin, ttran23
# Date: October 2017
# Assignment 2 : dpgen

(USAGE: dpgen netlistFile verilogFile )

Project reads in netlist files and creates a synthesizable verilog datapath implementation. Also calculates the estimated critical path and outputs it to console.

Rohin: wrote instruction conversion from netlist to verilog
Tam: wrote file output, verilog header and footer sections
Stephanie: wrote file input and critical path calculations